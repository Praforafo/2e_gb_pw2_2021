const express = require('express')
const server = express()
const mysql = require('mysql2')
const banco = mysql.createPool({
    user: 'root',
    password: 'minas',
    database: '2e_gb_2021',
    host: 'localhost',
    port: '3306'
})

server.get('/clientes', (req, res) => {
    const SQL = 'SELECT * FROM clientes'

    banco.getConnection((erro, con) => {
        if(erro)
    })
})

server.get('/testarconexao', (req, res) => {
    banco.getConnection((erro.com) => {
        if(erro){
            return res.status(500).send({
                mensagem: 'Erro no Servidor',
                detalhes: erro
            })
        }

        con.release()

        return res.status(200).send({
            mensagem :'Conexão estabelecidade com sucesso'
        })
    })
})

server.get('/', (req, res, next) => {
    return res.status(200).send({
        mensagem: 'Servidor funcionando!'
    })
})

server.listen(3000, () => {
    console.log('Em execução')
})

