<?php
    $nome = $_POST["nome"];
    $idade = $_POST["idade"];

    echo "Hello World";
    echo "<div>Seu nome é $nome, voce tem $idade anos.</div>";

    if($idade < 18){
        echo'<div>Voce é menor de idade!</div>';
    }else{
        echo'<div>Voce é maior de idade!</div>';
    }

    echo"<div><a href=\"index.php\">Voltar</a></div>";